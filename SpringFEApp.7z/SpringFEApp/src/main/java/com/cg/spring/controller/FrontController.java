package com.cg.spring.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class FrontController {

	@RequestMapping(value = "/getall", method = RequestMethod.GET)
	public ModelAndView getAllCustomers() {
		ModelAndView mv = new ModelAndView("getall");
		RestTemplate template = new RestTemplate();
		List<Customer> list = template.getForObject("http://localhost:9397/getall", ArrayList.class);
		mv.addObject("customers", list);
		return mv;
	}
	
	@RequestMapping(value="/hello")
	public String sayHello() {
		return "getall";
	}
}
