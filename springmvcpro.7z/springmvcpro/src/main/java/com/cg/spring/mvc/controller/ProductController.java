package com.cg.spring.mvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.method.support.ModelAndViewContainer;
import org.springframework.web.servlet.ModelAndView;

import com.cg.spring.mvc.beans.Product;
import com.cg.spring.mvc.service.IProductService;

@Controller
public class ProductController {

	@Autowired
	IProductService service;

	@RequestMapping(value = "/getall", method = RequestMethod.GET)
	public ModelAndView getAllProducts() {

		ModelAndView mv = new ModelAndView("showall");
		mv.addObject("products", service.getAllProducts());
		return mv;
	}

	@RequestMapping(value = "/addp", method = RequestMethod.GET)
	public ModelAndView addProduct() {

		ModelAndView m1v1 = new ModelAndView("add");
		m1v1.addObject("command", new Product());
		return m1v1;
	}

	@RequestMapping(value = "/addproduct", method = RequestMethod.POST)
	public String add(Product p) {
		service.add(p);
		return "redirect:/getall";
	}
	
	@RequestMapping(value = "/searchp", method = RequestMethod.GET)
	public ModelAndView SearchProduct() {

		ModelAndView m2v2 = new ModelAndView("Search");
		m2v2.addObject("command", new Product());
		return m2v2;
	}
	
	@RequestMapping(value = "/searchproduct", method = RequestMethod.GET)
	public ModelAndView SearchProoduct1(@RequestParam("id") int id) {
		ModelAndView mn=new ModelAndView("showone");
		mn.addObject("product", service.search(id));
		return mn;
		}

	
}
