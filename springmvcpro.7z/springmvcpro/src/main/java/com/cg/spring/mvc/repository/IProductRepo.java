package com.cg.spring.mvc.repository;

import java.util.List;

import org.springframework.stereotype.Repository;
@Repository
public interface IProductRepo<Product> {
 List<Product>  getAllProducts();
 void add(com.cg.spring.mvc.beans.Product p);
Product search(int id);
 
} 
