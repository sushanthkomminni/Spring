package com.cg.spring.jpa.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.spring.jpa.Customer;
import com.cg.spring.jpa.repository.ICustomerRepo;
@Component
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	ICustomerRepo repo;
	List<Customer> list=new ArrayList<>();
	public List<Customer> getAll() {
		
		 repo.findAll().forEach(list::add);
		return list;
	}
	

}
