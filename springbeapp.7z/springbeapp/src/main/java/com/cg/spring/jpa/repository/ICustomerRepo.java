package com.cg.spring.jpa.repository;

import org.springframework.data.jpa.repository.support.CrudMethodMetadata;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.spring.jpa.Customer;
@Repository
public interface ICustomerRepo extends CrudRepository<Customer, Integer>{

}
