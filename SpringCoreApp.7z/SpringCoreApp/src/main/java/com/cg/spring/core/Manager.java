package com.cg.spring.core;

public class Manager {
	   private int deptno;
	   private String name;
	   private long code;
	    public int getDeptno() {
		return deptno;
	}
	
	@Override
	public String toString() {
		return "Manager [deptno=" + deptno + ", name=" + name + ", code=" + code + "]";
	}

	public Manager(int deptno, String name, long code) {
		super();
		this.deptno = deptno;
		this.name = name;
		this.code = code;
	}

	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getCode() {
		return code;
	}
	public void setCode(long code) {
		this.code = code;
	}
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   

}
